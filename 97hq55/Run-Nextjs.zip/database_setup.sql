-- Create database (if not exists)
-- USE master;
-- GO
-- CREATE DATABASE [display_monitor];
-- GO

-- Use the database
USE [display_monitor];
GO

-- Create setting table
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='setting' AND xtype='U')
BEGIN
    CREATE TABLE [setting] (
        [id] INT PRIMARY KEY IDENTITY(1,1),
        [department] NVARCHAR(255) NOT NULL DEFAULT N'ตรวจโรคทั่วไป',
        [n_hospital] NVARCHAR(255) NOT NULL DEFAULT N'โรงพยาบาลชนบท',
        [n_room] NVARCHAR(255) NOT NULL DEFAULT N'ห้องตรวจ',
        [n_table] NVARCHAR(255) NOT NULL DEFAULT N'จุดซักประวัติ',
        [n_listtable] NVARCHAR(255) DEFAULT N'',
        [n_listroom] NVARCHAR(255) DEFAULT N'',
        [department_load] NVARCHAR(50) DEFAULT N'0',
        [department_room_load] NVARCHAR(50) DEFAULT N'0',
        [time_col] NVARCHAR(10) DEFAULT N'false',
        [table_arr] NVARCHAR(10) DEFAULT N'false',
        [table_arr2] NVARCHAR(10) DEFAULT N'false',
        [amount_boxL] INT DEFAULT 3,
        [amount_boxR] INT DEFAULT 0,
        [stem_surname] NVARCHAR(10) DEFAULT N'false',
        [stem_surname_table] NVARCHAR(10) DEFAULT N'false',
        [station_l] NVARCHAR(500) DEFAULT N'โต๊ะซักประวัติ 1,โต๊ะซักประวัติ 2,โต๊ะซักประวัติ 3',
        [station_r] NVARCHAR(500) DEFAULT N'',
        [stem_popup] NVARCHAR(10) DEFAULT N'false',
        [a_sound] NVARCHAR(10) DEFAULT N'true',
        [b_sound] NVARCHAR(10) DEFAULT N'false',
        [c_sound] NVARCHAR(10) DEFAULT N'false',
        [stem_name] NVARCHAR(255) NULL,
        [urgent_color] NVARCHAR(10) DEFAULT N'true',
        [lock_position] NVARCHAR(10) DEFAULT N'false',
        [lock_position_right] NVARCHAR(10) DEFAULT N'false',
        [urgent_level] NVARCHAR(10) DEFAULT N'false',
        [status_patient] NVARCHAR(10) DEFAULT N'false',
        [status_check] NVARCHAR(10) DEFAULT N'false',
        [ads] NVARCHAR(500) DEFAULT N'',
        [timeout] NVARCHAR(50) NULL,
        [pages] NVARCHAR(50) NULL,
        [urgent_setup] NVARCHAR(500) DEFAULT N'',
        [type] NVARCHAR(50) NULL,
        [alternate] NVARCHAR(50) NULL,
        [voice] NVARCHAR(50) NULL,
        [style_voice] NVARCHAR(50) NULL,
        [set_descrip] NVARCHAR(10) DEFAULT N'true',
        [set_notice] NVARCHAR(10) DEFAULT N'true',
        [time_wait] NVARCHAR(50) DEFAULT N'300',
        [listPage] NVARCHAR(500) DEFAULT N'',
        [limitNum] NVARCHAR(50) NULL,
        [speedLoop] NVARCHAR(50) NULL,
        [activeLoop] NVARCHAR(50) NULL,
        [created_at] DATETIME2 DEFAULT GETDATE(),
        [updated_at] DATETIME2 DEFAULT GETDATE()
    );
END
GO

-- Insert sample data
IF NOT EXISTS (SELECT * FROM [setting] WHERE [id] = 201)
BEGIN
    INSERT INTO [setting] ([id], [department], [n_hospital], [n_room], [n_table], [n_listtable], [n_listroom], [department_load], [department_room_load], [time_col], [table_arr], [table_arr2], [amount_boxL], [amount_boxR], [stem_surname], [stem_surname_table], [station_l], [station_r], [stem_popup], [a_sound], [b_sound], [c_sound], [stem_name], [urgent_color], [lock_position], [lock_position_right], [urgent_level], [status_patient], [status_check], [ads], [timeout], [pages], [urgent_setup], [type], [alternate], [voice], [style_voice], [set_descrip], [set_notice], [time_wait], [listPage], [limitNum], [speedLoop], [activeLoop])
    VALUES (201, N'ตรวจโรคทั่วไป', N'โรงพยาบาลชนบท', N'ห้องตรวจ', N'จุดซักประวัติ', N'', N'', N'31', N'29', N'false', N'false', N'false', 3, 0, N'false', N'false', N'โต๊ะซักประวัติ 1,โต๊ะซักประวัติ 2,โต๊ะซักประวัติ 3', N'', N'false', N'true', N'false', N'false', NULL, N'true', N'false', N'false', N'false', N'false', N'false', N'', NULL, NULL, N'', NULL, NULL, NULL, NULL, N'true', N'true', N'300', N'', NULL, NULL, NULL);
END

IF NOT EXISTS (SELECT * FROM [setting] WHERE [id] = 202)
BEGIN
    INSERT INTO [setting] ([id], [department], [n_hospital], [n_room], [n_table], [n_listtable], [n_listroom], [department_load], [department_room_load], [time_col], [table_arr], [table_arr2], [amount_boxL], [amount_boxR], [stem_surname], [stem_surname_table], [station_l], [station_r], [stem_popup], [a_sound], [b_sound], [c_sound], [stem_name], [urgent_color], [lock_position], [lock_position_right], [urgent_level], [status_patient], [status_check], [ads], [timeout], [pages], [urgent_setup], [type], [alternate], [voice], [style_voice], [set_descrip], [set_notice], [time_wait], [listPage], [limitNum], [speedLoop], [activeLoop])
    VALUES (202, N'ตรวจสุขภาพ', N'โรงพยาบาลเมือง', N'ห้องตรวจสุขภาพ', N'จุดลงทะเบียน', N'ไม่มีรายการ', N'', N'25', N'20', N'false', N'false', N'false', 2, 0, N'false', N'false', N'โต๊ะบริการ 1,โต๊ะบริการ 2', N'', N'false', N'true', N'false', N'false', NULL, N'true', N'false', N'false', N'false', N'false', N'false', N'', NULL, NULL, N'', NULL, NULL, NULL, NULL, N'true', N'true', N'300', N'', NULL, NULL, NULL);
END

IF NOT EXISTS (SELECT * FROM [setting] WHERE [id] = 203)
BEGIN
    INSERT INTO [setting] ([id], [department], [n_hospital], [n_room], [n_table], [n_listtable], [n_listroom], [department_load], [department_room_load], [time_col], [table_arr], [table_arr2], [amount_boxL], [amount_boxR], [stem_surname], [stem_surname_table], [station_l], [station_r], [stem_popup], [a_sound], [b_sound], [c_sound], [stem_name], [urgent_color], [lock_position], [lock_position_right], [urgent_level], [status_patient], [status_check], [ads], [timeout], [pages], [urgent_setup], [type], [alternate], [voice], [style_voice], [set_descrip], [set_notice], [time_wait], [listPage], [limitNum], [speedLoop], [activeLoop])
    VALUES (203, N'นัดตรวจ', N'โรงพยาบาลเอกชน', N'ห้องนัดตรวจ', N'จุดคัดกรอง', N'ไม่มีข้อมูล', N'', N'15', N'12', N'false', N'false', N'false', 1, 0, N'false', N'false', N'เคาน์เตอร์ 1', N'', N'false', N'true', N'false', N'false', NULL, N'true', N'false', N'false', N'false', N'false', N'false', N'', NULL, NULL, N'', NULL, NULL, NULL, NULL, N'true', N'true', N'300', N'', NULL, NULL, NULL);
END
GO

-- Create trigger to update updated_at timestamp
IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='tr_setting_update' AND xtype='TR')
BEGIN
    EXEC('
    CREATE TRIGGER [tr_setting_update]
    ON [setting]
    AFTER UPDATE
    AS
    BEGIN
        UPDATE [setting]
        SET [updated_at] = GETDATE()
        FROM [setting] s
        INNER JOIN inserted i ON s.[id] = i.[id]
    END
    ');
END
GO

-- Select all settings to verify
SELECT * FROM [setting];
GO
