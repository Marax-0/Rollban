-- =====================================================
-- ทดสอบระบบ TTS (เรียกคิว)
-- =====================================================

-- 1. ตรวจสอบข้อมูลปัจจุบัน
SELECT * FROM monitor_visit_info WHERE name='จุรี';

-- 2. ตั้งค่าเรียกคิว (status_call = 1)
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE name = 'จุรี';

-- 3. ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status_call, time_call 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 4. รีเซ็ตสถานะ (เมื่อเสร็จแล้ว)
-- UPDATE monitor_visit_info 
-- SET status_call = 0, time_call = NULL
-- WHERE name = 'จุรี';
