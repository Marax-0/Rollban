# การตั้งค่า Google Text-to-Speech (TTS)

## ขั้นตอนการตั้งค่า Google TTS API

### 1. สร้าง Google Cloud Project
1. ไปที่ [Google Cloud Console](https://console.cloud.google.com/)
2. สร้างโปรเจกต์ใหม่หรือเลือกโปรเจกต์ที่มีอยู่
3. เปิดใช้งาน Text-to-Speech API

### 2. สร้าง API Key
1. ไปที่ **APIs & Services** > **Credentials**
2. คลิก **Create Credentials** > **API Key**
3. คัดลอก API Key ที่สร้างขึ้นมา

### 3. ตั้งค่า Environment Variables
1. คัดลอกไฟล์ `env.example` เป็น `.env.local`
2. เพิ่ม Google TTS API Key:

```bash
NEXT_PUBLIC_GOOGLE_TTS_API_KEY=your_actual_api_key_here
```

### 4. เปิดใช้งาน Text-to-Speech API
1. ไปที่ **APIs & Services** > **Library**
2. ค้นหา "Text-to-Speech API"
3. คลิก **Enable**

## การใช้งาน

ระบบจะใช้ Google TTS เป็นหลัก และจะ fallback ไปใช้ browser TTS หากเกิดข้อผิดพลาด

### เสียงที่รองรับ
- `th-TH-Standard-A`: เสียงผู้ชายไทย (ค่าเริ่มต้น)
- `th-TH-Standard-B`: เสียงผู้หญิงไทย
- `th-TH-Standard-C`: เสียงผู้ชายไทย (สำเนียงต่าง)
- `th-TH-Standard-D`: เสียงผู้หญิงไทย (สำเนียงต่าง)
- `th-TH-Neural2-A`: เสียง Neural ผู้ชายไทย
- `th-TH-Neural2-B`: เสียง Neural ผู้หญิงไทย
- `th-TH-Neural2-C`: เสียง Neural ผู้ชายไทย (สำเนียงต่าง)
- `th-TH-Neural2-D`: เสียง Neural ผู้หญิงไทย (สำเนียงต่าง)

## การปรับแต่ง

คุณสามารถปรับแต่งเสียงได้ในไฟล์ `src/app/single/[id]/page.tsx`:

```typescript
await playGoogleTTS({
  text: text,
  language: 'th-TH',
  voice: THAI_VOICES.STANDARD_B, // เปลี่ยนเป็นเสียงผู้หญิง
  speed: 0.8, // เปลี่ยนความเร็ว (0.25 - 4.0)
  pitch: 1.2  // เปลี่ยนระดับเสียง (0.25 - 4.0)
});
```

## ราคา

Google TTS มีราคา:
- ฟรี: 1 ล้านตัวอักษรต่อเดือน
- เสียเงิน: $4.00 ต่อ 1 ล้านตัวอักษร

## การแก้ไขปัญหา

### ปัญหา: API Key ไม่ทำงาน
- ตรวจสอบว่า API Key ถูกต้อง
- ตรวจสอบว่า Text-to-Speech API เปิดใช้งานแล้ว
- ตรวจสอบว่า API Key มีสิทธิ์เข้าถึง Text-to-Speech API

### ปัญหา: เสียงไม่เล่น
- ระบบจะ fallback ไปใช้ browser TTS อัตโนมัติ
- ตรวจสอบ console เพื่อดู error messages

### ปัญหา: เสียงไม่ชัด
- ลองเปลี่ยนเสียงเป็น Neural voices (th-TH-Neural2-*)
- ปรับ speed และ pitch ตามต้องการ
