-- =====================================================
-- ทดสอบสถานะกำลังรับบริการ
-- =====================================================

-- 1. ตรวจสอบข้อมูลปัจจุบัน
SELECT * FROM monitor_visit_info WHERE name='จุรี';

-- 2. ตั้งค่าเป็นกำลังรับบริการ (status = 'กำลัง')
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 1'
WHERE name = 'จุรี';

-- 3. ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status, station 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 4. ทดสอบหลายโต๊ะ
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 2'
WHERE name = 'จุรี';

-- 5. ตรวจสอบข้อมูลกำลังรับบริการทั้งหมด
SELECT name, surname, visit_q_no, status, station
FROM monitor_visit_info 
WHERE status = 'กำลัง' AND visit_date = CAST(GETDATE() AS DATE);

-- 6. รีเซ็ตสถานะ (เมื่อเสร็จแล้ว)
-- UPDATE monitor_visit_info 
-- SET status = 'รอ', station = NULL
-- WHERE name = 'จุรี';
