# การทดสอบระบบแบบเร็ว

## 🎯 ทดสอบ TTS (เรียกคิว)

### 1. รันคำสั่ง SQL ใน Data Studio:
```sql
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE name = 'จุรี';
```

### 2. ผลลัพธ์ที่คาดหวัง:
- ✅ ปรากฏ popup เรียกคิว
- ✅ มีเสียง TTS พูด
- ✅ แสดงหมายเลขคิวและชื่อ

---

## 🔴 ทดสอบแถบข้ามคิว

### 1. รันคำสั่ง SQL ใน Data Studio:
```sql
UPDATE monitor_visit_info 
SET status = 'ข้าม'
WHERE name = 'จุรี';
```

### 2. ผลลัพธ์ที่คาดหวัง:
- ✅ แถบสีแดงปรากฏที่ด้านล่าง
- ✅ หมายเลขคิวเลื่อนผ่านไป
- ✅ แสดงชื่อ-นามสกุล

---

## 🟢 ทดสอบกำลังรับบริการ

### 1. รันคำสั่ง SQL ใน Data Studio:
```sql
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 1'
WHERE name = 'จุรี';
```

### 2. ผลลัพธ์ที่คาดหวัง:
- ✅ แสดงในส่วน "กำลังรับบริการ" ทางด้านขวา
- ✅ แสดงที่โต๊ะซักประวัติ 1

---

## 🔄 รีเซ็ตสถานะ

### เมื่อเสร็จการทดสอบ:
```sql
UPDATE monitor_visit_info 
SET status_call = 0, status = 'รอ', station = NULL, time_call = NULL
WHERE name = 'จุรี';
```

---

## 📱 ตรวจสอบผลลัพธ์

1. เปิดเบราว์เซอร์: `http://localhost:3000/single/[id]`
2. ดูการเปลี่ยนแปลงในหน้าจอ
3. ตรวจสอบ Console (F12) หากมีปัญหา

---

## ⚠️ หมายเหตุ

- ใช้ `GETDATE()` สำหรับวันที่ปัจจุบัน
- ตรวจสอบ `visit_date` ให้ตรงกับวันที่ในระบบ
- ทดสอบทีละขั้นตอนเพื่อดูผลลัพธ์ชัดเจน
