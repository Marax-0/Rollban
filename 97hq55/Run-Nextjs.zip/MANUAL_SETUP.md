# การตั้งค่า Google TTS API Key ด้วยตนเอง

## API Key ที่คุณให้มา:
```
AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs
```

## ขั้นตอนการตั้งค่า:

### 1. สร้างไฟล์ .env.local
1. เปิดโฟลเดอร์โปรเจกต์: `C:\Users\66967\Downloads\97hq55\`
2. สร้างไฟล์ใหม่ชื่อ `.env.local` (ไม่มีนามสกุล)
3. ใส่เนื้อหาดังนี้:

```bash
NEXT_PUBLIC_GOOGLE_TTS_API_KEY=AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs
```

### 2. ตรวจสอบไฟล์
ไฟล์ `.env.local` ควรมีเนื้อหาดังนี้:
```
NEXT_PUBLIC_GOOGLE_TTS_API_KEY=AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs
```

### 3. รีสตาร์ทเซิร์ฟเวอร์
1. หยุดเซิร์ฟเวอร์ development (Ctrl+C)
2. รันใหม่: `npm run dev`

### 4. ทดสอบการทำงาน
1. เข้าไปที่: `http://localhost:3000/tts-test`
2. ทดสอบการเล่นเสียง

## การแก้ไขปัญหา:

### หากไม่สามารถสร้างไฟล์ .env.local:
1. เปิด Command Prompt หรือ PowerShell
2. ไปที่โฟลเดอร์โปรเจกต์: `cd C:\Users\66967\Downloads\97hq55`
3. รันคำสั่ง:
   ```cmd
   echo NEXT_PUBLIC_GOOGLE_TTS_API_KEY=AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs > .env.local
   ```

### หากเสียงไม่เล่น:
1. ตรวจสอบ Console ในเบราว์เซอร์ (F12)
2. ดูว่ามี error message หรือไม่
3. ระบบจะ fallback ไปใช้ browser TTS อัตโนมัติ

### หาก API Key ไม่ทำงาน:
1. ตรวจสอบใน Google Cloud Console ว่า Text-to-Speech API เปิดใช้งานแล้ว
2. ตรวจสอบว่า API Key มีสิทธิ์เข้าถึง Text-to-Speech API
3. ตรวจสอบว่า API Key ไม่หมดอายุ

## หมายเหตุ:
- ไฟล์ `.env.local` จะไม่ถูก commit ขึ้น git
- Google TTS มีค่าใช้จ่าย 1 ล้านตัวอักษรฟรีต่อเดือน
- หากเกิดข้อผิดพลาด ระบบจะ fallback ไปใช้ browser TTS อัตโนมัติ

## ไฟล์ที่เกี่ยวข้อง:
- `src/lib/google-tts.ts` - ฟังก์ชัน Google TTS
- `src/app/single/[id]/page.tsx` - ระบบเรียกคิวหลัก
- `src/app/tts-test/page.tsx` - หน้าทดสอบ
- `src/components/TTSTest.tsx` - Component ทดสอบ
