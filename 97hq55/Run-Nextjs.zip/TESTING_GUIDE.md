# คู่มือการทดสอบระบบ TTS และแถบข้ามคิว

## ขั้นตอนการทดสอบ

### 1. **ทดสอบระบบ TTS (เรียกคิว)**

#### ขั้นตอน:
1. เปิด Data Studio
2. รันคำสั่ง SQL:
```sql
-- ตรวจสอบข้อมูลปัจจุบัน
SELECT * FROM monitor_visit_info WHERE name='จุรี';

-- ตั้งค่าเรียกคิว
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE name = 'จุรี';
```

#### ผลลัพธ์ที่คาดหวัง:
- ระบบจะแสดง popup เรียกคิว
- จะมีเสียง TTS พูด "ขอเชิญหมายเลข [หมายเลขคิว] ที่ [โต๊ะ] ครับ"
- ใช้ Google TTS (หากตั้งค่า API Key แล้ว) หรือ browser TTS

### 2. **ทดสอบแถบข้ามคิว**

#### ขั้นตอน:
1. รันคำสั่ง SQL:
```sql
-- ตั้งค่าเป็นข้ามคิว
UPDATE monitor_visit_info 
SET status = 'ข้าม'
WHERE name = 'จุรี';
```

#### ผลลัพธ์ที่คาดหวัง:
- แถบสีแดงจะปรากฏที่ด้านล่างสุด
- แสดงข้อความ "คิวที่โดนข้าม"
- หมายเลขคิวจะเลื่อนผ่านไปทางซ้ายอย่างต่อเนื่อง

### 3. **ทดสอบสถานะอื่นๆ**

#### ตั้งค่าเป็นกำลังรับบริการ:
```sql
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 1'
WHERE name = 'จุรี';
```

#### ผลลัพธ์ที่คาดหวัง:
- ข้อมูลจะแสดงในส่วน "กำลังรับบริการ" ทางด้านขวา
- แถบข้ามคิวจะหายไป (หากไม่มีคนอื่นที่โดนข้าม)

### 4. **ทดสอบหลายคนพร้อมกัน**

#### เพิ่มข้อมูลทดสอบ:
```sql
INSERT INTO monitor_visit_info (vn, name, surname, visit_q_no, code_dept_id, visit_date, status)
VALUES 
('TEST001', 'สมชาย', 'ใจดี', 'ก001', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST002', 'สมหญิง', 'รักดี', 'ก002', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST003', 'สมศักดิ์', 'เก่งดี', 'ก003', 'DEPT001', GETDATE(), 'ข้าม');
```

#### ผลลัพธ์ที่คาดหวัง:
- แถบข้ามคิวจะแสดงหลายคน
- หมายเลขคิวจะเลื่อนผ่านไปเรื่อยๆ

## การตรวจสอบผลลัพธ์

### 1. **ตรวจสอบในเบราว์เซอร์**
- เปิด `http://localhost:3000/single/[id]` (id คือ ID ของ setting)
- ดูการเปลี่ยนแปลงในหน้าจอ

### 2. **ตรวจสอบ Console**
- กด F12 เพื่อเปิด Developer Tools
- ดู Console เพื่อตรวจสอบ error หรือ log

### 3. **ตรวจสอบ Network**
- ใน Developer Tools ไปที่ tab Network
- ดูการเรียก API `/api/data/call` และ `/api/data/skipped`

## การแก้ไขปัญหา

### 1. **TTS ไม่ทำงาน**
- ตรวจสอบ Console ว่ามี error หรือไม่
- ตรวจสอบการตั้งค่า Google TTS API Key
- ลองใช้ browser TTS (fallback)

### 2. **แถบข้ามคิวไม่แสดง**
- ตรวจสอบว่ามีข้อมูล status = 'ข้าม' หรือไม่
- ตรวจสอบ API `/api/data/skipped`
- ตรวจสอบ Console เพื่อดู error

### 3. **ข้อมูลไม่อัปเดต**
- ตรวจสอบ Server-Sent Events (SSE)
- ตรวจสอบการเชื่อมต่อฐานข้อมูล
- รีเฟรชหน้าจอ

## คำสั่ง SQL สำหรับการทดสอบ

### ทดสอบเรียกคิว:
```sql
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE name = 'จุรี';
```

### ทดสอบข้ามคิว:
```sql
UPDATE monitor_visit_info 
SET status = 'ข้าม'
WHERE name = 'จุรี';
```

### ทดสอบกำลังรับบริการ:
```sql
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 1'
WHERE name = 'จุรี';
```

### รีเซ็ตสถานะ:
```sql
UPDATE monitor_visit_info 
SET status_call = 0, status = 'รอ', station = NULL, time_call = NULL
WHERE name = 'จุรี';
```

## หมายเหตุ

- ใช้ `GETDATE()` สำหรับวันที่ปัจจุบัน
- ตรวจสอบ `visit_date` ให้ตรงกับวันที่ในระบบ
- ใช้ `code_dept_id` ที่ตรงกับ `department_load` ใน setting
- ทดสอบทีละขั้นตอนเพื่อดูผลลัพธ์ชัดเจน

## การลบข้อมูลทดสอบ

เมื่อเสร็จสิ้นการทดสอบ:
```sql
DELETE FROM monitor_visit_info WHERE vn IN ('TEST001', 'TEST002', 'TEST003');
```
