# ฟีเจอร์ค้นหาคนที่โดนข้ามคิว

## ฟีเจอร์ใหม่ที่เพิ่มเข้ามา

### 1. **ช่องค้นหา (Search Box)**
- อยู่ด้านบนของแถบข้ามคิว
- ค้นหาด้วยหมายเลขคิวหรือชื่อ-นามสกุล
- แสดงผลแบบ real-time (ขณะพิมพ์)

### 2. **การกรองข้อมูล (Filtering)**
- กรองตามหมายเลขคิว
- กรองตามชื่อ
- กรองตามนามสกุล
- กรองตามชื่อ-นามสกุลรวม

### 3. **ตัวนับจำนวน (Counter)**
- แสดงจำนวนคนที่โดนข้ามในหัวข้อ
- อัปเดตตามผลการค้นหา
- รูปแบบ: "คิวที่โดนข้าม (5)" → "คิวที่โดนข้าม (2)" เมื่อค้นหา

## วิธีการใช้งาน

### 1. **ค้นหาด้วยหมายเลขคิว**
```
พิมพ์: "ก001" หรือ "001"
ผลลัพธ์: แสดงคนที่มีหมายเลขคิว ก001
```

### 2. **ค้นหาด้วยชื่อ**
```
พิมพ์: "สมชาย" หรือ "ชาย"
ผลลัพธ์: แสดงคนที่มีชื่อ "สมชาย" หรือมีคำ "ชาย"
```

### 3. **ค้นหาด้วยนามสกุล**
```
พิมพ์: "ใจดี" หรือ "ใจ"
ผลลัพธ์: แสดงคนที่มีนามสกุล "ใจดี" หรือมีคำ "ใจ"
```

### 4. **ค้นหาด้วยชื่อ-นามสกุลรวม**
```
พิมพ์: "สมชาย ใจดี"
ผลลัพธ์: แสดงคนที่มีชื่อ-นามสกุลตรงกัน
```

## ฟีเจอร์พิเศษ

### 1. **ปุ่มล้าง (Clear Button)**
- ปรากฏเมื่อมีการพิมพ์ในช่องค้นหา
- คลิกเพื่อล้างคำค้นหา
- สีแดงเพื่อแสดงความสำคัญ

### 2. **ข้อความ "ไม่พบผลลัพธ์"**
- แสดงเมื่อไม่พบข้อมูลที่ตรงกับคำค้นหา
- รูปแบบ: "ไม่พบผลลัพธ์สำหรับ '[คำค้นหา]'"
- สไตล์ italic และสีขาวจาง

### 3. **การค้นหาแบบ Case-Insensitive**
- ไม่สนใจตัวพิมพ์ใหญ่-เล็ก
- "สมชาย" = "สมชาย" = "สมชาย"

## การออกแบบ

### 1. **ช่องค้นหา**
- สีขาวโปร่งใส
- Border radius 20px
- Focus state สีน้ำเงิน
- Placeholder text สีเทา

### 2. **ปุ่มล้าง**
- วงกลมสีแดง
- ขนาด 18x18px
- Hover effect scale 1.1
- ไอคอน ✕

### 3. **Responsive Design**
- Desktop: ช่องค้นหาอยู่ข้างๆ หัวข้อ
- Tablet: ช่องค้นหาอยู่ใต้หัวข้อ
- Mobile: ช่องค้นหาขยายเต็มความกว้าง

## การทดสอบ

### 1. **ทดสอบการค้นหา**
```sql
-- เพิ่มข้อมูลทดสอบ
INSERT INTO monitor_visit_info (vn, name, surname, visit_q_no, code_dept_id, visit_date, status)
VALUES 
('TEST001', 'สมชาย', 'ใจดี', 'ก001', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST002', 'สมหญิง', 'รักดี', 'ก002', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST003', 'สมศักดิ์', 'เก่งดี', 'ก003', 'DEPT001', GETDATE(), 'ข้าม');
```

### 2. **ทดสอบการค้นหา**
- พิมพ์ "ก001" → ควรแสดงเฉพาะสมชาย
- พิมพ์ "สม" → ควรแสดงทั้ง 3 คน
- พิมพ์ "ใจดี" → ควรแสดงเฉพาะสมชาย
- พิมพ์ "xyz" → ควรแสดง "ไม่พบผลลัพธ์"

### 3. **ทดสอบปุ่มล้าง**
- พิมพ์คำค้นหา → ปุ่มล้างปรากฏ
- คลิกปุ่มล้าง → คำค้นหาหายไป
- ข้อมูลแสดงทั้งหมดกลับมา

## การทำงานของระบบ

### 1. **State Management**
```typescript
const [skippedSearchKeyword, setSkippedSearchKeyword] = useState('');
```

### 2. **Filtering Function**
```typescript
const filteredSkippedData = useCallback(() => {
  if (!skippedSearchKeyword.trim()) {
    return skippedData;
  }
  
  const keyword = skippedSearchKeyword.toLowerCase().trim();
  return skippedData.filter(item => {
    const queueNo = String(item.visit_q_no || '').toLowerCase();
    const name = String(item.name || '').toLowerCase();
    const surname = String(item.surname || '').toLowerCase();
    const fullName = `${name} ${surname}`.toLowerCase();
    
    return queueNo.includes(keyword) || 
           name.includes(keyword) || 
           surname.includes(keyword) ||
           fullName.includes(keyword);
  });
}, [skippedData, skippedSearchKeyword]);
```

### 3. **Real-time Updates**
- ใช้ `useCallback` เพื่อ optimize performance
- อัปเดตทันทีเมื่อ `skippedSearchKeyword` เปลี่ยน
- ไม่ต้องกด Enter หรือปุ่มค้นหา

## ข้อดี

### 1. **ใช้งานง่าย**
- ไม่ต้องเรียนรู้คำสั่งพิเศษ
- ค้นหาได้หลายวิธี
- ผลลัพธ์แสดงทันที

### 2. **ประสิทธิภาพดี**
- ใช้ `useCallback` เพื่อป้องกัน re-render
- กรองข้อมูลใน client-side
- ไม่ต้องเรียก API เพิ่ม

### 3. **User Experience ดี**
- มีปุ่มล้างคำค้นหา
- แสดงข้อความเมื่อไม่พบผลลัพธ์
- Responsive design ทุกขนาดหน้าจอ

## ไฟล์ที่เกี่ยวข้อง

- `src/app/single/[id]/page.tsx` - ระบบค้นหา
- `src/app/single/[id]/page.module.css` - CSS styles
- `src/app/api/data/skipped/route.ts` - API endpoint

## การพัฒนาต่อ

### 1. **ฟีเจอร์ที่อาจเพิ่ม**
- ค้นหาด้วยวันที่
- ค้นหาด้วยเวลา
- ค้นหาด้วยสถานะ
- Export ข้อมูลที่ค้นหา

### 2. **การปรับปรุง**
- เพิ่ม keyboard shortcuts
- เพิ่มการค้นหาแบบ fuzzy
- เพิ่มการบันทึกประวัติการค้นหา
- เพิ่มการค้นหาด้วย regex
