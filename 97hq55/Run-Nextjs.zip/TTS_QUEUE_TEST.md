# การทดสอบ TTS Queue System

## ปัญหาที่แก้ไข
เมื่อรันคำสั่ง SQL หลายคำสั่งพร้อมกัน (เช่น อัปเดต 2 คนพร้อมกัน) ระบบ TTS จะเล่นซ้อนกัน ทำให้เสียงฟังไม่ชัด

## วิธีแก้ไข
เพิ่มระบบ **TTS Queue** ที่จะ:
- เก็บรายการ TTS ที่ต้องเล่นใน queue
- เล่นทีละรายการตามลำดับ
- รอ 2 วินาทีระหว่างการเล่นแต่ละรายการ
- แสดงจำนวนคิวที่รอใน popup

## การทดสอบ

### 1. ทดสอบคำสั่งเดียว (ปกติ)
```sql
UPDATE monitor_visit_info 
SET station = 'โต๊ะซักประวัติ 1', status = 'กำลัง', status_call = '1' 
WHERE vn = '680921063625';
```

**ผลลัพธ์ที่คาดหวัง:**
- ✅ แสดง popup เรียกคิว
- ✅ เล่นเสียง TTS 1 ครั้ง
- ✅ ไม่มี queue indicator

### 2. ทดสอบคำสั่งหลายคำสั่งพร้อมกัน
```sql
UPDATE monitor_visit_info SET station = 'โต๊ะซักประวัติ 1', status = 'กำลัง', status_call = '1' WHERE vn = '680921063625';
UPDATE monitor_visit_info SET station = 'โต๊ะซักประวัติ 2', status = 'กำลัง', status_call = '1' WHERE vn = '680921060901';
```

**ผลลัพธ์ที่คาดหวัง:**
- ✅ แสดง popup เรียกคิวคนแรก
- ✅ แสดง "รออีก 1 คิว" ใน popup
- ✅ เล่นเสียง TTS คนแรก
- ✅ รอ 2 วินาที
- ✅ เล่นเสียง TTS คนที่สอง
- ✅ ไม่มีเสียงซ้อนกัน

### 3. ทดสอบคำสั่ง 3 คำสั่งพร้อมกัน
```sql
UPDATE monitor_visit_info SET station = 'โต๊ะซักประวัติ 1', status = 'กำลัง', status_call = '1' WHERE vn = '680921063625';
UPDATE monitor_visit_info SET station = 'โต๊ะซักประวัติ 2', status = 'กำลัง', status_call = '1' WHERE vn = '680921060901';
UPDATE monitor_visit_info SET station = 'โต๊ะซักประวัติ 3', status = 'กำลัง', status_call = '1' WHERE vn = 'TEST001';
```

**ผลลัพธ์ที่คาดหวัง:**
- ✅ แสดง popup เรียกคิวคนแรก
- ✅ แสดง "รออีก 2 คิว" ใน popup
- ✅ เล่นเสียง TTS ตามลำดับ
- ✅ รอ 2 วินาทีระหว่างแต่ละคน
- ✅ ไม่มีเสียงซ้อนกัน

## ฟีเจอร์ใหม่

### 1. **TTS Queue System**
- เก็บรายการ TTS ที่ต้องเล่น
- เล่นทีละรายการตามลำดับ
- ป้องกันการเล่นซ้อนกัน

### 2. **Queue Indicator**
- แสดงจำนวนคิวที่รอใน popup
- มี animation pulse เพื่อดึงดูดสายตา
- สีส้มเพื่อแสดงความสำคัญ

### 3. **Timing Control**
- รอ 2 วินาทีระหว่างการเล่นแต่ละรายการ
- ป้องกันการเล่นเร็วเกินไป
- ให้เวลาผู้ฟังได้ยินเสียงชัดเจน

## การทำงานของระบบ

### 1. **เมื่อมี TTS ใหม่:**
```
1. เพิ่มข้อมูลเข้า queue
2. ตรวจสอบว่ามี TTS กำลังเล่นอยู่หรือไม่
3. หากไม่มี ให้เริ่มเล่น TTS แรกใน queue
4. แสดง popup พร้อม queue indicator
```

### 2. **เมื่อ TTS จบ:**
```
1. รอ 2 วินาที
2. ตรวจสอบ queue ว่ามีรายการถัดไปหรือไม่
3. หากมี ให้เล่น TTS ถัดไป
4. หากไม่มี ให้ปิด popup
```

### 3. **Queue Management:**
```
- เพิ่มรายการ: setTtsQueue(prev => [...prev, data])
- ลบรายการแรก: setTtsQueue(prev => prev.slice(1))
- ตรวจสอบจำนวน: ttsQueue.length
```

## การแก้ไขปัญหา

### 1. **TTS ไม่เล่นตามลำดับ**
- ตรวจสอบ `isPlayingTTS` state
- ตรวจสอบ `processTTSQueue` function
- ตรวจสอบ Console เพื่อดู error

### 2. **Queue indicator ไม่แสดง**
- ตรวจสอบ `ttsQueue.length > 0`
- ตรวจสอบ CSS class `.queueIndicator`
- ตรวจสอบ animation `pulse`

### 3. **เสียงยังซ้อนกัน**
- ตรวจสอบ `setIsPlayingTTS(true)` ทำงานหรือไม่
- ตรวจสอบ timing 2 วินาที
- ตรวจสอบ Google TTS API

## ไฟล์ที่เกี่ยวข้อง

- `src/app/single/[id]/page.tsx` - ระบบ TTS Queue
- `src/app/single/[id]/page.module.css` - CSS สำหรับ queue indicator
- `src/lib/google-tts.ts` - ฟังก์ชัน Google TTS

## หมายเหตุ

- ระบบจะทำงานอัตโนมัติเมื่อมี `status_call = 1`
- Queue จะถูกเคลียร์เมื่อไม่มีรายการเหลือ
- สามารถปรับ timing ได้ใน `setTimeout(() => { setIsPlayingTTS(false); }, 2000)`
