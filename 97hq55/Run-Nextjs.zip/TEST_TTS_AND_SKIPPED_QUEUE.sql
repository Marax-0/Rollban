-- =====================================================
-- คำสั่ง SQL สำหรับทดสอบระบบ TTS และแถบข้ามคิว
-- =====================================================

-- 1. ตรวจสอบข้อมูลปัจจุบัน
SELECT * FROM monitor_visit_info WHERE name='จุรี';

-- 2. ทดสอบระบบเรียกคิว (TTS)
-- ตั้งค่า status_call = 1 เพื่อเรียกคิว
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE name = 'จุรี';

-- ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status_call, time_call 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 3. ทดสอบแถบข้ามคิว
-- ตั้งค่า status = 'ข้าม' เพื่อแสดงในแถบข้ามคิว
UPDATE monitor_visit_info 
SET status = 'ข้าม'
WHERE name = 'จุรี';

-- ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 4. ทดสอบสถานะอื่นๆ
-- ตั้งค่า status = 'กำลัง' (กำลังรับบริการ)
UPDATE monitor_visit_info 
SET status = 'กำลัง', station = 'โต๊ะซักประวัติ 1'
WHERE name = 'จุรี';

-- ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status, station 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 5. ทดสอบหลายคนพร้อมกัน
-- เพิ่มข้อมูลทดสอบ
INSERT INTO monitor_visit_info (vn, name, surname, visit_q_no, code_dept_id, visit_date, status)
VALUES 
('TEST001', 'สมชาย', 'ใจดี', 'ก001', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST002', 'สมหญิง', 'รักดี', 'ก002', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST003', 'สมศักดิ์', 'เก่งดี', 'ก003', 'DEPT001', GETDATE(), 'ข้าม');

-- ตรวจสอบข้อมูลทั้งหมด
SELECT name, surname, visit_q_no, status 
FROM monitor_visit_info 
WHERE status = 'ข้าม' AND visit_date = CAST(GETDATE() AS DATE);

-- 6. ทดสอบเรียกคิวหลายคน
UPDATE monitor_visit_info 
SET status_call = 1, time_call = GETDATE()
WHERE visit_q_no IN ('ก001', 'ก002', 'ก003');

-- 7. ลบข้อมูลทดสอบ (เมื่อเสร็จแล้ว)
-- DELETE FROM monitor_visit_info WHERE vn IN ('TEST001', 'TEST002', 'TEST003');

-- 8. รีเซ็ตสถานะจุรี
UPDATE monitor_visit_info 
SET status_call = 0, status = 'รอ', station = NULL, time_call = NULL
WHERE name = 'จุรี';

-- =====================================================
-- คำสั่งสำหรับตรวจสอบข้อมูลในระบบ
-- =====================================================

-- ตรวจสอบข้อมูลเรียกคิว (status_call = 1)
SELECT name, surname, visit_q_no, status_call, time_call
FROM monitor_visit_info 
WHERE status_call = 1 AND visit_date = CAST(GETDATE() AS DATE);

-- ตรวจสอบข้อมูลข้ามคิว (status = 'ข้าม')
SELECT name, surname, visit_q_no, status
FROM monitor_visit_info 
WHERE status = 'ข้าม' AND visit_date = CAST(GETDATE() AS DATE);

-- ตรวจสอบข้อมูลกำลังรับบริการ (status = 'กำลัง')
SELECT name, surname, visit_q_no, status, station
FROM monitor_visit_info 
WHERE status = 'กำลัง' AND visit_date = CAST(GETDATE() AS DATE);

-- ตรวจสอบข้อมูลทั้งหมดของวันนี้
SELECT name, surname, visit_q_no, status, status_call, station, time_call
FROM monitor_visit_info 
WHERE visit_date = CAST(GETDATE() AS DATE)
ORDER BY check_in;
