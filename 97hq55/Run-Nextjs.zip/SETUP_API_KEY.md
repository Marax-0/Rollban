# การตั้งค่า Google TTS API Key

## API Key ที่คุณให้มา:
```
AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs
```

## ขั้นตอนการตั้งค่า:

### 1. สร้างไฟล์ .env.local ในโฟลเดอร์ root ของโปรเจกต์
สร้างไฟล์ `.env.local` ในโฟลเดอร์ `C:\Users\66967\Downloads\97hq55\` ด้วยเนื้อหาดังนี้:

```bash
# Database Configuration for MSSQL
DB_USER=your_username
DB_PASSWORD=your_password
DB_SERVER=your_server_name_or_ip
DB_NAME=your_database_name

# Optional: Database Port (if not using default 1433)
DB_PORT=1433

# Optional: Connection Timeout (in milliseconds)
DB_TIMEOUT=30000

# Optional: Connection Pool Settings
DB_POOL_MIN=0
DB_POOL_MAX=10

# Environment
NODE_ENV=development

# Google Text-to-Speech API Configuration
NEXT_PUBLIC_GOOGLE_TTS_API_KEY=AIzaSyBQQZs6vlHEnrWYztiSELPkjiQSpmeVSjs
```

### 2. ตรวจสอบการตั้งค่า
หลังจากสร้างไฟล์ `.env.local` แล้ว:

1. **รีสตาร์ทเซิร์ฟเวอร์ development:**
   ```bash
   npm run dev
   ```

2. **ทดสอบการทำงาน:**
   - เข้าไปที่ `http://localhost:3000/tts-test`
   - ทดสอบการเล่นเสียง

### 3. ตรวจสอบใน Google Cloud Console
ให้แน่ใจว่า:
- Text-to-Speech API เปิดใช้งานแล้ว
- API Key มีสิทธิ์เข้าถึง Text-to-Speech API
- API Key ไม่หมดอายุ

## การทดสอบ

หลังจากตั้งค่าเสร็จแล้ว คุณสามารถทดสอบได้ที่:
- `/tts-test` - หน้าทดสอบเสียง
- ระบบเรียกคิวปกติจะใช้ Google TTS อัตโนมัติ

## หมายเหตุ
- ไฟล์ `.env.local` จะไม่ถูก commit ขึ้น git
- หากเกิดข้อผิดพลาด ระบบจะ fallback ไปใช้ browser TTS อัตโนมัติ
- Google TTS มีค่าใช้จ่าย 1 ล้านตัวอักษรฟรีต่อเดือน
