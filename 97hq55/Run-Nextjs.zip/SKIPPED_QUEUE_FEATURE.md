# แถบแสดงคนที่โดนข้ามคิว

## ฟีเจอร์ที่เพิ่มเข้ามา

### 1. **แถบแสดงคนที่โดนข้ามคิว**
- แสดงที่ด้านล่างสุดของหน้าจอ
- แสดงเฉพาะเมื่อมีคนที่โดนข้ามคิว (status = 'ข้าม')
- มีการเลื่อนผ่านหมายเลขคิวอย่างต่อเนื่อง

### 2. **API Endpoint ใหม่**
- `/api/data/skipped` - ดึงข้อมูลคนที่โดนข้ามคิว
- รองรับการกรองตาม department_load และ visit_date
- ส่งข้อมูลกลับในรูปแบบ JSON

### 3. **การออกแบบ**
- สีแดงเพื่อแสดงความสำคัญ
- การเลื่อนผ่านแบบต่อเนื่อง (30 วินาทีต่อรอบ)
- Responsive design สำหรับหน้าจอขนาดต่างๆ
- เอฟเฟกต์ hover และ animation

## การทำงาน

### 1. **การดึงข้อมูล**
```typescript
const fetchSkippedData = useCallback(async (departmentLoad: string) => {
  const result = await fetchWithErrorHandling('/api/data/skipped', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ 
      department_load: departmentLoad,
      visit_date: today
    }),
  });
  
  if (result && result.success) {
    setSkippedData(result.data);
  }
}, []);
```

### 2. **การแสดงผล**
```typescript
{skippedData.length > 0 && (
  <div className={styles.skippedBar}>
    <div className={styles.skippedBarContent}>
      <div className={styles.skippedHeader}>
        <span>คิวที่โดนข้าม</span>
      </div>
      <div className={styles.skippedQueueContainer}>
        <div className={styles.skippedQueueList}>
          {skippedData.map((item, index) => (
            <div key={item.id || index} className={styles.skippedQueueItem}>
              <span className={styles.skippedQueueNumber}>
                {item.visit_q_no}
              </span>
              <span className={styles.skippedQueueName}>
                {item.name} {item.surname}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
)}
```

## ข้อกำหนดของฐานข้อมูล

### ตาราง `monitor_visit_info`
ต้องมีคอลัมน์:
- `status` - สถานะของผู้ป่วย ('ข้าม' สำหรับคนที่โดนข้ามคิว)
- `visit_q_no` - หมายเลขคิว
- `name` - ชื่อผู้ป่วย
- `surname` - นามสกุลผู้ป่วย
- `code_dept_id` - รหัสแผนก
- `visit_date` - วันที่

### ตัวอย่างข้อมูล
```sql
INSERT INTO monitor_visit_info (status, visit_q_no, name, surname, code_dept_id, visit_date)
VALUES ('ข้าม', 'ก001', 'สมชาย', 'ใจดี', 'DEPT001', '2024-01-15');
```

## การตั้งค่า

### 1. **ไม่มีอะไรต้องตั้งค่าเพิ่มเติม**
- ระบบจะทำงานอัตโนมัติเมื่อมีข้อมูล status = 'ข้าม'
- แถบจะแสดงเฉพาะเมื่อมีคนที่โดนข้ามคิว

### 2. **การปรับแต่ง**
- สามารถปรับความเร็วการเลื่อนใน CSS: `animation-duration`
- สามารถเปลี่ยนสีและสไตล์ใน CSS
- สามารถปรับจำนวนข้อมูลที่แสดงได้

## การใช้งาน

### 1. **อัปเดตสถานะเป็น 'ข้าม'**
```sql
UPDATE monitor_visit_info 
SET status = 'ข้าม' 
WHERE vn = '123456789';
```

### 2. **ระบบจะแสดงอัตโนมัติ**
- แถบจะปรากฏที่ด้านล่างสุด
- หมายเลขคิวจะเลื่อนผ่านไปอย่างต่อเนื่อง
- แสดงชื่อ-นามสกุลของผู้ป่วย

## ฟีเจอร์พิเศษ

### 1. **Animation**
- `slideUp` - แถบเลื่อนขึ้นจากด้านล่าง
- `scrollLeft` - หมายเลขคิวเลื่อนผ่านไปทางซ้าย

### 2. **Responsive Design**
- ปรับขนาดตามหน้าจอ
- ความเร็วการเลื่อนแตกต่างกันตามขนาดหน้าจอ

### 3. **Visual Effects**
- Gradient background สีแดง
- Backdrop blur effect
- Hover effects
- Text shadows

## การแก้ไขปัญหา

### 1. **แถบไม่แสดง**
- ตรวจสอบว่ามีข้อมูล status = 'ข้าม' ในฐานข้อมูล
- ตรวจสอบ API endpoint `/api/data/skipped`
- ตรวจสอบ Console ในเบราว์เซอร์

### 2. **ข้อมูลไม่ถูกต้อง**
- ตรวจสอบโครงสร้างฐานข้อมูล
- ตรวจสอบการเชื่อมต่อ API
- ตรวจสอบการตั้งค่า department_load

### 3. **การแสดงผลผิดปกติ**
- ตรวจสอบ CSS classes
- ตรวจสอบ responsive design
- ตรวจสอบ browser compatibility

## ไฟล์ที่เกี่ยวข้อง

- `src/app/api/data/skipped/route.ts` - API endpoint
- `src/app/single/[id]/page.tsx` - หน้าหลัก
- `src/app/single/[id]/page.module.css` - CSS styles
- `database_setup.sql` - โครงสร้างฐานข้อมูล

## การพัฒนาต่อ

### 1. **ฟีเจอร์ที่อาจเพิ่ม**
- การกรองตามเวลา
- การแสดงสถิติ
- การส่งแจ้งเตือน
- การ export ข้อมูล

### 2. **การปรับปรุง**
- เพิ่มการ caching
- ปรับปรุง performance
- เพิ่ม accessibility
- เพิ่มการทดสอบ
