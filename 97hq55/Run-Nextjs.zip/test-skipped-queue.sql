-- =====================================================
-- ทดสอบแถบข้ามคิว
-- =====================================================

-- 1. ตรวจสอบข้อมูลปัจจุบัน
SELECT * FROM monitor_visit_info WHERE name='จุรี';

-- 2. ตั้งค่าเป็นข้ามคิว (status = 'ข้าม')
UPDATE monitor_visit_info 
SET status = 'ข้าม'
WHERE name = 'จุรี';

-- 3. ตรวจสอบผลลัพธ์
SELECT name, surname, visit_q_no, status 
FROM monitor_visit_info 
WHERE name = 'จุรี';

-- 4. ทดสอบหลายคนพร้อมกัน
INSERT INTO monitor_visit_info (vn, name, surname, visit_q_no, code_dept_id, visit_date, status)
VALUES 
('TEST001', 'สมชาย', 'ใจดี', 'ก001', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST002', 'สมหญิง', 'รักดี', 'ก002', 'DEPT001', GETDATE(), 'ข้าม'),
('TEST003', 'สมศักดิ์', 'เก่งดี', 'ก003', 'DEPT001', GETDATE(), 'ข้าม');

-- 5. ตรวจสอบข้อมูลข้ามคิวทั้งหมด
SELECT name, surname, visit_q_no, status 
FROM monitor_visit_info 
WHERE status = 'ข้าม' AND visit_date = CAST(GETDATE() AS DATE);

-- 6. รีเซ็ตสถานะ (เมื่อเสร็จแล้ว)
-- UPDATE monitor_visit_info 
-- SET status = 'รอ'
-- WHERE name = 'จุรี';

-- 7. ลบข้อมูลทดสอบ (เมื่อเสร็จแล้ว)
-- DELETE FROM monitor_visit_info WHERE vn IN ('TEST001', 'TEST002', 'TEST003');
